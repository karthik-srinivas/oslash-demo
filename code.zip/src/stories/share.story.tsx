import React from "react";
import {storiesOf} from "@storybook/react";
import {SharePanel} from "../components/SharePanel/SharePanel";
import Dropdown, {DropdownContainer, DropdownTrigger} from "../components/Dropdown";


storiesOf("share", module)
    .add("panel", () => {
        return <Dropdown>
            <DropdownTrigger theme="primary" icon="share">Share</DropdownTrigger>
            <DropdownContainer className="rounded-2x">
                <SharePanel/>
            </DropdownContainer>
        </Dropdown>
    })

