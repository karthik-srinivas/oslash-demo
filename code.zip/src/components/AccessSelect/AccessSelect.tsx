import React from "react";
import {listOfSelectItem} from "../Select/Select";
import Select from "../Select";
import "./style.scss"
const AccessSelect:React.FC<{
    rightAligned?:boolean
}> = ({rightAligned=false})=>{
    const items: listOfSelectItem =
        [{key: "Full Access", value: "full"},
            {key: "Can edit", value: "edit"},
            {key: "Can view", value: "view"},
            {key: "No Access", value: "no", className: "error"}]

    return <div className="access-drop">
        <Select  defaultVal={"no"} items={items} rightAligned={rightAligned} />
    </div>
}

export default AccessSelect;