import React from "react";
import "./style.scss"

const TagInput: React.FC<{
    onInputChange: {(event:React.ChangeEvent<HTMLInputElement>):void}
}> = ({onInputChange}) => {
    return <div className="tag-input">
        <div className={"tag-group"}>

        </div>
        <input className="form-control" type="text" placeholder="Search emails, names or groups" onChange={onInputChange} />
    </div>
}

export default TagInput;