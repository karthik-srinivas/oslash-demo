import React, {useCallback, useContext, useEffect, useRef} from "react";
import Button from "../Button";
import {IButton} from "../Button/Button";
import useClickTrigger from "./hooks/useClickTrigger";
import {DropdownContext} from "./DropdownContext";


const DropdownTrigger: React.FC<IButton> =({children, ...rest}, ref) => {

    const {show, visible, hidden} = useContext(DropdownContext);

    const toggleFn = useCallback(() => {
        if (show) {
            hidden()
        } else {
            visible();
        }
    },[show])

    const [bind] = useClickTrigger(toggleFn);


    return <Button {...rest} {...bind} >
        {children}
    </Button>
}

export default DropdownTrigger