import React from "react";

const useClickTrigger = (fn: Function) => {
    const onClick: { (event: React.MouseEvent<HTMLButtonElement>): void } = (event) => {
        fn()
    };

    return [{onClick}]
}

export default useClickTrigger;