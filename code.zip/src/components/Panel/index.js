import Panel from "./Panel";
import PanelFoot from "./PanelFoot";
import PanelHead from "./PanelHead";
import PanelBody from "./PanelBody";
export {
    PanelFoot,
    PanelHead,
    PanelBody,
}

export default Panel;