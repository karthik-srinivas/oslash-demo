import React, {useEffect, useState} from "react";
import Panel, {PanelBody, PanelFoot, PanelHead} from "../Panel";
import "./style.scss";
import Button from "../Button";
import OslashIcon from '../../assets/images/oslash.svg';
import Avatar from '../../assets/images/Avatar.svg';
import AccessSelect from "../AccessSelect";
import TagInput from "../TagInput";
import clsx from "clsx";
import {Group, Person} from "components/SharePanel/ShareContext";

export const ShareHeader = () => {
    return <PanelHead>
        <div className="flex align-center">
            <i className="os-icon os-web"/>
            <div className="head-group">
                <p>Share to web</p>
                <p>Publish and share link with anyone</p>
            </div>
        </div>
        <button className="toggle">
            <span/>
        </button>
    </PanelHead>
}


export const ShareFooter: React.FC = ({children}) => {
    return <div className={"flex w-full"}>
        <a href={"https://google.co.in"} target={"_blank"}><i className={"os-icon os-question"}/>learn about sharing</a>
        {children}
    </div>

}

const InputGroup: React.FC<{
    onFocus: { (): void }
}> = ({onFocus}) => {
    return <div className="search-bar">
        <input type="text" placeholder="People, emails, groups" onFocus={onFocus}/>
        <Button>Invite</Button>
    </div>
}


const ShareGroup: React.FC<{
    avatar: string,
    text: string
    subtext: string
}> = ({avatar, text, subtext}) => {
    return <div className="oslash-group">
        <div className={"flex align-center mt-1"}>
            <img className={"rounded-full"} src={avatar} alt={"avatar"}/>
            <div className="os-text-group">
                <p>{text}</p>
                <p>{subtext}</p>
            </div>
            <AccessSelect rightAligned={true}/>
        </div>
    </div>
}

export const SharePanel: React.FC = () => {
    return <Panel className={"share"}>
        <ShareHeader/>
        <PanelBody>
            <InputGroup onFocus={() => {

            }}/>

            {/*TODO: make all dropdown as portal */}
            <ShareGroup avatar={OslashIcon} text={"Everyone at OSlash"} subtext={"25 workspace members"}/>
            <ShareGroup avatar={Avatar} text={"Tom cook"} subtext={"tom@oslash.com"}/>

        </PanelBody>
        <PanelFoot>
            <ShareFooter>
                <Button isSmall={true} theme={"ghost"} preIcon={"link"} className={"ml-auto"}>
                    copy link
                </Button>
            </ShareFooter>
        </PanelFoot>
    </Panel>
}

type searchGroupType = "person" | "group";


const ListItem: React.FC<{
    avatar?: string | null | undefined,
    title: string
    type: "person" | "group"
}> = ({title, avatar = undefined, type}) => {
    return <div className={"list__item"}>
        <div className={clsx({"group_avatar": type === "group", "avatar": type === "person"})}>
            {avatar ? <img src={avatar} alt={"avatar"}/> : <span>{title[0].toUpperCase()}</span>}
        </div>
        <div>
            {title}
        </div>
    </div>
}

const ListGroup: React.FC<{
    type: searchGroupType,
    listOfGroup: Array<Person | Group>,
    filterTarget: string | null
}> = ({type, listOfGroup, filterTarget}) => {

    const [list, setList] = useState<Array<Person | Group>>([])

    useEffect(() => {
        setList(listOfGroup)
    }, [listOfGroup])


    useEffect(() => {
        if (filterTarget) {
            let _filtered = listOfGroup.filter(item => item.name.toLowerCase().indexOf(filterTarget.toLowerCase()) > -1)
            setList(_filtered)
        } else {
            setList(listOfGroup)
        }
    }, [filterTarget])

    /*TODO: useDebounce */
    return <>
        {!!list.length && <div className={"list__wrap"}>
            <div className="list__heading">Select a {type}</div>
            <div className="list__group">
                {list.map((item) => <ListItem key={item.name} type={type} title={item.name} avatar={item.avatar}/>)}
            </div>

        </div>}
    </>
}

export const SearchPanel = () => {
    const [searchText, setSearchText] = useState<string | null>(null)
    return <Panel className={"search"}>
        <PanelHead type={"gray"}>
            <div className="flex">
                <TagInput onInputChange={(event) => {
                    setSearchText(event.target.value)
                }}/>
                <fieldset disabled className={"ml-auto flex field-set"}>
                    <AccessSelect rightAligned={true}/>
                    <Button isSmall>Invite</Button>
                </fieldset>
            </div>
        </PanelHead>
        <PanelBody>
            <ListGroup filterTarget={searchText} type={"person"} listOfGroup={[
                {name: "Wade Cooper", email: "wc@gmail.com", avatar: Avatar},
                {name: "Arlene Mccoy", email: "am@gmail.com", avatar: Avatar},
                {name: "Koushik Shetty", email: "ks@gmail.com", avatar: Avatar},
            ]}/>

            <ListGroup filterTarget={searchText} type={"group"} listOfGroup={[
                {name: "Product", members: 25},
                {name: "Engineering", members: 25},
                {name: "Infra", members: 25},
                {name: "HR Team", members: 25},
            ]}/>
        </PanelBody>
        <PanelFoot type={"gray"}>
            <ShareFooter>
                <Button isSmall={true} theme={"ghost"} className={"ml-auto"}>Back</Button>
            </ShareFooter>
        </PanelFoot>
    </Panel>
}

export const ShareSearchContainer = () => {


    return <SearchPanel/>
}


export default SharePanel;