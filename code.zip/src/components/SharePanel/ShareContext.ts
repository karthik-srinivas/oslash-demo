import {createContext} from "react";
import {selectItem} from "../Select/Select";

export type Person = {
    name: string,
    email: string,
    avatar?: string | null | undefined,
}

export type withAccess = {
    access: selectItem | null,
}

export type PersonWithAccess = Person & withAccess;

export type Group = Omit<Person, "email"> & {
    members: number
}

export type GroupWithAccess = Group & withAccess;


type shareStateType = {
    search: {
        selectedItems: Array<PersonWithAccess | GroupWithAccess>
        accessType: selectItem | null
    },
    share: {
        listOfInvites: Array<PersonWithAccess | GroupWithAccess>,
        oslashAccess: selectItem | null
    }
}

type stateWithCallbacks = {
    state: shareStateType,
    setPanel: Function,
    setSearchText: Function
    updateSelectedSearchItem: Function,
    updateSelectedSearchAccess: Function,
    setInvites: Function,
    setOslashAccess: Function
}

const State: shareStateType = {
    search: {
        selectedItems: [],
        accessType: null
    },
    share: {
        listOfInvites: [],
        oslashAccess: null
    }
}

const defaultCtxState: stateWithCallbacks = {
    state: {
        search: {
            selectedItems: [],
            accessType: null
        },
        share: {
            listOfInvites: [],
            oslashAccess: null
        }
    },
    setPanel: () => {
    },
    setSearchText: () => {
    },
    updateSelectedSearchItem: () => {
    },
    updateSelectedSearchAccess: () => {
    },
    setInvites: () => {
    },
    setOslashAccess: () => {
    },
}


export const ShareContext = createContext<stateWithCallbacks>(defaultCtxState)