export enum Icon{
    link="os-link",
    question="os-question",
    web="os-web",
    dropDown="os-dropdown",
    share="os-share"
}
